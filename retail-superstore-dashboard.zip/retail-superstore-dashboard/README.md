# Retail Superstore Dashboard

A two-page sales dashboard for a retail superstore, built as interactive web pages and matched with a Power BI theme.

- **Overview** (`index.html`): total sales, profit, orders, customers and products; sales by region; profit share by city; customer categories; brand share; Brand A sales by store; and a sales-to-profit waterfall.
- **Timeline** (`timeline.html`): sales by year and by quarter against the previous period, cumulative profit by month and region, top products, and a monthly profit heatmap.

Each chart has hover tooltips and a **Table** button that shows the numbers behind it. The pages work in light and dark mode and on phones.

## Run it

Open `index.html` in a browser. There is nothing to install. Fonts load from Google Fonts, so an internet connection gives the intended look.

To host it on GitHub Pages: **Settings → Pages → Deploy from a branch → `main` / root**.

## Power BI theme

The `powerbi/` folder has a matching theme and background for a Power BI report.

1. In Power BI Desktop, go to **View → Themes → Browse for themes** and choose `powerbi/powerbi_theme.json`.
2. Click an empty area of the page, open **Format page → Canvas background → Image**, and choose `powerbi/powerbi_background.png`. Set **Image fit** to *Fit* and **Transparency** to 0%.

The background is 1920×1080. Set the page size to 16:9 so it fits.

## About the numbers

Totals, regions, cities, brands and customer categories match the original Power BI report. The yearly, quarterly, monthly, store and product series were read off the report's charts, so treat them as close estimates. Costs are total sales minus total profit.
